<div id='bottom'>
		<p>copyright<a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></p>
</div>
	<?php wp_footer(); ?>
</body>
</html>

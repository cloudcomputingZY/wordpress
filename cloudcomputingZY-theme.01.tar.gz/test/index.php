<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" />
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/script.js"></script>
<title>index page</title>
</head>
<body id='bg'>
<div class="nav">
     <ul>
	  <li onmouseover="showsub(this)" onmouseout="hidesub(this)">
		<a href='#'>课程简介</a>
	      <ul>
		<?php $var=0;$category_id= get_cat_id('课程简介'); ?>
		<?php query_posts('cat='.$category_id);      
    		if(have_posts()) : while (have_posts()) : the_post();
		echo '<li><a href="' . get_permalink() .'">' . get_the_title() .'</a></li>';
		if(++$var==4){echo '<li><a href="' . get_category_link($category_id) .'">' .'more'.'</a></li>';break;}
		endwhile;endif; ?>  
		</ul>
	  </li>
	 <li onmouseover="showsub(this)" onmouseout="hidesub(this)"><a href="#">学习资料</a>
	      <ul>
		<?php $var=0;$category_id= get_cat_id('学习资料'); ?>
		<?php query_posts('cat='.$category_id);      
    		if(have_posts()) : while (have_posts()) : the_post();
		echo '<li><a href="' . get_permalink() .'">' . get_the_title() .'</a></li>';
		if(++$var==4){echo '<li><a href="' . get_category_link($category_id) .'">' .'more'.'</a></li>';break;}
		endwhile;endif; ?>  
		</ul>
	 </li>
	 <li onmouseover="showsub(this)" onmouseout="hidesub(this)"><a href="#">其他</a>
	      <ul>
		<?php $var=0;$category_id= get_cat_id('其他'); ?>
		<?php query_posts('cat='.$category_id);      
    		if(have_posts()) : while (have_posts()) : the_post();
		echo '<li><a href="' . get_permalink() .'">' . get_the_title() .'</a></li>';
		if(++$var==4){echo '<li><a href="' . get_category_link($category_id) .'">' .'more'.'</a></li>';break;}
		endwhile;endif; ?>  
	      </ul>
	 </li>
     </ul>
</div>
</body>
</html>




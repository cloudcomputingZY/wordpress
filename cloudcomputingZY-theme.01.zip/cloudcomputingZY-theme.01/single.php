<?php
if(in_category('课程简介')){
	include(TEMPLATEPATH.'/single-nocomment.php');
}else{
	include(TEMPLATEPATH.'/single-comment.php');
}
?>

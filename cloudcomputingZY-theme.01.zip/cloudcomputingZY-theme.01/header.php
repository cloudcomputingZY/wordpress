<!doctype html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo get_bloginfo('charset'); ?>" />
	
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" href="<?php bloginfo('template_directory');?>/div.css" type="text/css" />
	<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/404.js"></script>
	<?php wp_head(); ?>
</head>
<body>
<div id='top'>
	<h1><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></h1>
</div>



